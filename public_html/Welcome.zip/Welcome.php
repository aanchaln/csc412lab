<body>

Welcome <?php echo $_POST["name1"]; ?><br>
<?php echo $_POST["name2"]; ?>
Your email address is: <?php echo $_POST["email"]; ?>

</body>

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

